export default function App() {
  const products = [
    {
      name: "Stockholm Sofa",
      desc: "Low-profile seating with soft linen texture and relaxed proportions.",
      image:
        "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=80",
    },
    {
      name: "Oak Coffee Table",
      desc: "Solid oak surface with softened edges and a warm natural finish.",
      image:
        "https://images.unsplash.com/photo-1532372320572-cda25653a694?auto=format&fit=crop&w=900&q=80",
    },
    {
      name: "Nord Dining Set",
      desc: "A refined dining setup made for bright, open living spaces.",
      image:
        "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=80",
    },
    {
      name: "Luna Bed Frame",
      desc: "A quiet bedroom piece with clean lines and gentle material contrast.",
      image:
        "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
    },
  ];

  return (
    <div className="site">
      <style>{`
        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
        }

        .site {
          min-height: 100vh;
          background: #f7f5f0;
          color: #20201d;
          font-family: Inter, Arial, sans-serif;
        }

        .header {
          position: sticky;
          top: 0;
          z-index: 10;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 22px 56px;
          background: rgba(247, 245, 240, 0.92);
          backdrop-filter: blur(16px);
          border-bottom: 1px solid #ded8cc;
        }

        .brand {
          font-size: 24px;
          font-weight: 600;
          letter-spacing: 0;
        }

        .nav {
          display: flex;
          align-items: center;
          gap: 28px;
        }

        .nav a {
          color: #4f514b;
          text-decoration: none;
          font-size: 14px;
        }

        .instagram {
          border: 1px solid #20201d;
          background: #20201d;
          color: white;
          padding: 11px 18px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 14px;
        }

        .hero {
          display: grid;
          grid-template-columns: 1fr 0.9fr;
          gap: 56px;
          align-items: center;
          max-width: 1180px;
          margin: 0 auto;
          padding: 72px 56px 64px;
        }

        .eyebrow {
          color: #6d7569;
          font-size: 13px;
          text-transform: uppercase;
          letter-spacing: 1.6px;
          margin-bottom: 18px;
        }

        .hero h1 {
          max-width: 680px;
          margin: 0;
          font-size: clamp(44px, 7vw, 84px);
          line-height: 0.95;
          font-weight: 600;
          letter-spacing: 0;
        }

        .hero p {
          max-width: 570px;
          margin: 28px 0 0;
          color: #5f625c;
          line-height: 1.8;
          font-size: 18px;
        }

        .heroImage {
          width: 100%;
          aspect-ratio: 4 / 5;
          object-fit: cover;
          border-radius: 8px;
        }

        .section {
          max-width: 1180px;
          margin: 0 auto;
          padding: 24px 56px 88px;
        }

        .sectionHeader {
          display: flex;
          justify-content: space-between;
          align-items: end;
          gap: 24px;
          margin-bottom: 28px;
        }

        .sectionHeader h2 {
          margin: 0;
          font-size: 34px;
          font-weight: 500;
        }

        .sectionHeader p {
          max-width: 360px;
          margin: 0;
          color: #686b65;
          line-height: 1.6;
        }

        .grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 18px;
        }

        .card {
          background: #fffdfa;
          border: 1px solid #e3ddd2;
          border-radius: 8px;
          overflow: hidden;
        }

        .card img {
          width: 100%;
          height: 260px;
          object-fit: cover;
          display: block;
        }

        .cardContent {
          padding: 22px;
        }

        .card h3 {
          margin: 0 0 10px;
          font-size: 20px;
          font-weight: 500;
        }

        .card p {
          margin: 0;
          color: #62655f;
          line-height: 1.65;
          font-size: 15px;
        }

        .footer {
          display: flex;
          justify-content: space-between;
          gap: 20px;
          padding: 34px 56px;
          color: #6b6d68;
          border-top: 1px solid #ded8cc;
          font-size: 14px;
        }

        @media (max-width: 900px) {
          .header {
            padding: 18px 24px;
          }

          .nav a {
            display: none;
          }

          .hero {
            grid-template-columns: 1fr;
            padding: 48px 24px;
          }

          .heroImage {
            aspect-ratio: 16 / 11;
          }

          .section {
            padding: 16px 24px 64px;
          }

          .sectionHeader {
            display: block;
          }

          .sectionHeader p {
            margin-top: 12px;
          }

          .grid {
            grid-template-columns: 1fr;
          }

          .footer {
            padding: 28px 24px;
            flex-direction: column;
          }
        }
      `}</style>

      <header className="header">
        <div className="brand">A-lines Furniture</div>

        <nav className="nav">
          <a href="#collection">Collection</a>
          <a href="#studio">Studio</a>
          <button
            className="instagram"
            onClick={() =>
              window.open("https://instagram.com/a.lines.furniture", "_blank")
            }
          >
            Instagram
          </button>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div>
            <div className="eyebrow">New collection</div>
            <h1>Calm design for modern living.</h1>
            <p>
              A refined furniture catalog shaped around natural materials,
              balanced proportions, and pieces that make a room feel lighter.
            </p>
          </div>

          <img
            className="heroImage"
            src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1100&q=80"
            alt="Bright living room with neutral furniture"
          />
        </section>

        <section className="section" id="collection">
          <div className="sectionHeader">
            <h2>Featured Collection</h2>
            <p>
              Soft textures, honest materials, and simple silhouettes for
              everyday rooms.
            </p>
          </div>

          <div className="grid">
            {products.map((product) => (
              <article className="card" key={product.name}>
                <img src={product.image} alt={product.name} />

                <div className="cardContent">
                  <h3>{product.name}</h3>
                  <p>{product.desc}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="footer">
        <span>A-lines Furniture</span>
        <span>(c) 2026</span>
      </footer>
    </div>
  );
}
